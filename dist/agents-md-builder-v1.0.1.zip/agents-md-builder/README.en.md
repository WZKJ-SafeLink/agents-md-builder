# AGENTS.md Builder

Version 1.0.1 · Safe Link · Apache-2.0

A local Agent Skill that turns repository evidence and confirmed engineering decisions into actionable AGENTS.md instructions. Modes: CREATE, DISCOVER, AUDIT, OPTIMIZE, HIERARCHY, UPDATE and MIGRATE. Chinese is the default; English output is supported. No paid API, database, backend, Docker or MCP is required.

## Use

Install the agents-md-builder folder in an Agent Skills host, select an authorized repository and ask:

> Generate an AGENTS.md candidate for this repository, preserving confirmed requirements.

> Audit my AI coding instructions. Report evidence, risks and assessment coverage.

> Compare the previous and current stack profiles and propose instruction updates.

Python 3.10+ tools perform bounded static analysis only. The host agent performs language understanding, version research, semantic generation and review. Without Python, follow the same bounded manual workflow; offline operation uses local knowledge with an explicit verification limitation.

## Commands

Run from the skill directory. Use real authorized paths and new output destinations. On Windows, `py -3` may replace `python`.

```text
python scripts/detect_stack.py --root /authorized/project
python scripts/generate_agents.py --root /authorized/project --output-dir /new-candidates --language en
python scripts/evaluate_agents.py --file /new-candidates/AGENTS.candidate.md --root /authorized/project
python -m unittest discover -s tests -v
python scripts/validate_skill.py --root .
python scripts/package_skill.py --root . --output dist/agents-md-builder-v1.0.1.zip
```

Existing instructions are never silently replaced. Explicit overwrite authorization and a matching original SHA-256 are required. Scripts do not execute discovered commands or upload repository contents. Linked paths are rejected; use canonical filesystem paths when system aliases are symlinks.

The portable archive uses name/description frontmatter and a single agents-md-builder wrapper folder. `--platform workbuddy` adds the documented marketplace fields using release/publisher.json and places SKILL.md directly at the ZIP root. WorkBuddy resources use category-prefixed filenames in one resource-directory level, with rewritten links and compatible runtime lookup. Version 1.0.0 was rejected by the platform for excessive directory nesting; use the 1.0.1 WorkBuddy archive. Both formats include a checksum manifest and are revalidated after extraction. The fixed archive has not yet been uploaded to WorkBuddy or approved by its marketplace.

See the [user guide](docs/USER_GUIDE.md), [privacy policy](docs/PRIVACY.md), [security policy](SECURITY.md), [release instructions](docs/WORKBUDDY_PUBLISH.md). Referenced third-party material retains its own rights; see [notices](THIRD_PARTY_NOTICES.md).
