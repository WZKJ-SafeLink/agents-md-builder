# AGENTS.md 智能规范助手

AGENTS.md Builder 1.0.1 · Safe Link · Apache-2.0

本地 Agent Skill：从项目配置、目录及代表性代码中提取证据，帮助宿主智能体生成、审查、评分、精简和维护项目专属 AGENTS.md。支持 CREATE、DISCOVER、AUDIT、OPTIMIZE、HIERARCHY、UPDATE、MIGRATE；默认中文，也可生成英文。无需收费 API、数据库、后端、Docker 或 MCP。

## 最快使用

在支持 Agent Skills 的宿主中安装包含 SKILL.md 的 agents-md-builder 文件夹，选择工程后输入：

> 帮我分析当前项目并生成 AGENTS.md，保留已有规范，先给候选文件。

> 帮我只读审查这份 AGENTS.md，给出评分覆盖率、风险和优化建议。

> 项目升级后，比较旧新技术栈和规范，生成差异候选。

Python 3.10+ 可用时自动使用标准库工具；缺失时宿主可按安全工作流手工静态读取和生成。离线可使用内置知识库，明确未经实时核验。智能体执行自然语言理解与语义生成；脚本不声称完整语义推理。

## 本地 CLI

以下命令从 Skill 目录执行，路径替换为授权工程与新输出目录。Windows 可用 `py -3` 替代 `python`；不依赖特定 Shell。

```text
python scripts/scan_project.py --root /authorized/project
python scripts/detect_stack.py --root /authorized/project --output /new-report/profile.json
python scripts/generate_agents.py --root /authorized/project --output-dir /new-candidates --hierarchy
python scripts/validate_agents.py --file /new-candidates/AGENTS.candidate.md --root /authorized/project
python scripts/evaluate_agents.py --file /new-candidates/AGENTS.candidate.md --root /authorized/project
```

脚本仅提供静态证据及候选，宿主进一步检查版本、架构和语义。生成不执行项目命令。已有文件不可静默覆盖，覆盖需明确授权与原文 SHA-256。扫描默认不跟随链接，包含系统别名路径时请使用规范化真实路径。具体参数见每个脚本 `--help`。

## 开发与发布

```text
python -m unittest discover -s tests -v
python scripts/validate_skill.py --root .
python scripts/package_skill.py --root . --output dist/agents-md-builder-v1.0.1.zip
python scripts/package_skill.py --root . --platform workbuddy --output dist/agents-md-builder-workbuddy-v1.0.1.zip
```

打包采用允许清单、固定 ZIP 时间戳和 SHA-256 manifest；重新解压并验证结构。WorkBuddy 包根据官方格式增加展示字段与 Safe Link 作者；通用入口只保留 name/description。每个输出路径必须是新文件，重建请选新文件名。包内不含测试、开发期 AGENTS.md 和环境配置。

WorkBuddy 上传使用1.0.1专用包：ZIP 根直接是 SKILL.md，references/assets 采用类别前缀文件名且不含嵌套子目录。1.0.0被平台以目录层级超限拒绝，不能再用旧包上传。源码与通用包仍保留按主题分层；打包器同步改写文档引用，工具兼容两种资源布局。

WorkBuddy 的实机导入、市场审核和数值限制未确认事项见 [发布说明](docs/WORKBUDDY_PUBLISH.md)。没有通过实机测试前不宣称已获平台认证。

## 文档

- [完整用户手册](docs/USER_GUIDE.md)
- [设计与工具边界](docs/DESIGN.md)
- [规则编写](docs/RULE_AUTHORING.md)
- [评分说明](docs/EVALUATION.md)
- [隐私](docs/PRIVACY.md) 与 [安全](SECURITY.md)
- [知识库索引](references/INDEX.md) 与 [资料核验记录](references/sources/official-sources.md)
- [English README](README.en.md)

原创内容适用 [Apache-2.0](LICENSE)。第三方文档仅链接和独立总结，见 [第三方声明](THIRD_PARTY_NOTICES.md)。
